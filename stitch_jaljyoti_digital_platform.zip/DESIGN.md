---
name: Jaljyoti Core
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3e4947'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6e7977'
  outline-variant: '#bdc9c6'
  surface-tint: '#006a63'
  primary: '#005c55'
  on-primary: '#ffffff'
  primary-container: '#0f766e'
  on-primary-container: '#a3faef'
  inverse-primary: '#80d5cb'
  secondary: '#006398'
  on-secondary: '#ffffff'
  secondary-container: '#5bb8fe'
  on-secondary-container: '#00476e'
  tertiary: '#005a6a'
  on-tertiary: '#ffffff'
  tertiary-container: '#007488'
  on-tertiary-container: '#c6f2ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf2e8'
  primary-fixed-dim: '#80d5cb'
  on-primary-fixed: '#00201d'
  on-primary-fixed-variant: '#00504a'
  secondary-fixed: '#cce5ff'
  secondary-fixed-dim: '#93ccff'
  on-secondary-fixed: '#001d31'
  on-secondary-fixed-variant: '#004b73'
  tertiary-fixed: '#acedff'
  tertiary-fixed-dim: '#4cd7f6'
  on-tertiary-fixed: '#001f26'
  on-tertiary-fixed-variant: '#004e5c'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 4px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system embodies a "Humanist Lab" aesthetic—merging the clinical precision of biotechnology with the approachable clarity of a premium consumer experience. It avoids the coldness of traditional scientific software by utilizing expansive white space, soft geometry, and high-fidelity depth.

The style is a synthesis of **Minimalism** and **Glassmorphism**, emphasizing structural clarity and layered information. It prioritizes legibility and data-density without causing cognitive load, ensuring that water-quality metrics feel like insights rather than raw data. The emotional response is one of absolute trust, technological sophistication, and environmental stewardship.

## Colors
The palette is rooted in the "Aqueous Spectrum." The Primary Deep Teal provides an anchor of authority and scientific depth, while the Ocean Blue and Cyan accents introduce movement and vitality, reminiscent of clean, flowing water.

- **Primary & Secondary:** Used for high-level brand moments, primary actions, and active states.
- **Backgrounds:** Use Pure White for main content areas to maximize contrast. Soft Gray is reserved for page-level backgrounds to define the canvas, while the Very Light Blue acts as a subtle container for specific data sections or lateral navigation.
- **Typography:** Dark Slate ensures maximum AAA accessibility for body text, while Muted Gray is used for metadata and secondary labels.

## Typography
The typographic scale is designed for high-precision reading. **Manrope** provides a modern, geometric character for headings, conveying innovation and structural integrity. **Inter** is used for all functional and body text to ensure maximum legibility across dense data tables and technical reports.

Generous line heights (1.5x - 1.6x) are mandated for body copy to prevent visual fatigue during long-form scientific analysis. Small labels and "Overlines" should utilize the 0.05em letter spacing and uppercase styling to distinguish them from interactive elements.

## Layout & Spacing
This design system utilizes a **Fixed-Fluid Hybrid Grid**. Content is centered within a 1280px max-width container for desktop viewports to maintain the premium, editorial feel of a high-end journal. 

- **The 8px Rhythm:** All spacing (padding, margins, gaps) must be increments of 8px (or 4px for micro-adjustments).
- **Desktop:** 12-column grid with 24px gutters. Use large 40px margins to allow the UI to "breathe."
- **Tablet:** 8-column grid with 20px gutters.
- **Mobile:** 4-column grid with 16px gutters.
- **Negative Space:** Prioritize vertical "air" between sections (80px - 120px) to signify distinct scientific modules.

## Elevation & Depth
Elevation is communicated through **Ambient Shadows** and **Tonal Layering** rather than heavy borders. The hierarchy follows a physical stacking model:

1.  **Base (Level 0):** Pure White (#FFFFFF) or Soft Gray (#F8FAFC).
2.  **Card/Surface (Level 1):** White background with a subtle 1px border (#E2E8F0) and a soft, multi-layered shadow (0px 4px 20px rgba(15, 23, 42, 0.04)).
3.  **Floating/Overlay (Level 2):** Menus and modals use a tighter, more defined shadow (0px 10px 30px rgba(15, 23, 42, 0.08)) and a 12px backdrop-blur for a glassmorphic effect.

Avoid pure black shadows; all shadows should be tinted with the Dark Slate (#0F172A) text color at low opacities to maintain a cohesive, "natural" look.

## Shapes
The shape language is "Hyper-Soft Modern." We use a generous corner radius to offset the technical nature of water-quality data, making the software feel more human-centric.

- **Cards & Containers:** Default to 24px (`rounded-xl`).
- **Interactive Elements:** Buttons and Input Fields use 12px - 16px (`rounded-lg`).
- **Status Pills:** Fully rounded (pill-shaped) to distinguish them from clickable buttons.
- **Visual Cues:** When nesting elements, the inner radius should be 8px smaller than the outer radius to maintain visual harmony.

## Components
- **Buttons:** Primary buttons use a gradient from Ocean Blue to Deep Teal. Secondary buttons are "Ghost" style with a 1px border and a subtle hover fill of Very Light Blue.
- **Cards:** White surfaces with 24px corner radius. Header sections within cards should have a subtle bottom divider (#F1F5F9).
- **Data Visualizations:** Charts should use the Primary, Secondary, and Accent colors for data series. Grids within charts must be minimal, using #F1F5F9.
- **Input Fields:** Large (48px height) with 12px radius. On focus, the border transitions to Ocean Blue with a 3px soft outer glow.
- **Chips/Status:** Use low-saturation background tints of the feedback colors (e.g., 10% opacity) with high-saturation text for clarity and "Apple-esque" elegance.
- **Lists:** Technical lists should have 16px of vertical padding per item, utilizing thin dividers and Manrope Bold for primary identifiers.